# DOM — Ver para entender

Proyecto para **interns**: claro, visual, práctico. Poca teoría pesada, mucho “ver para entender”.

## Cómo ejecutar

1. Abre `index.html` en el navegador.
2. Abre la **consola** (F12) y prueba: `console.log(document);` y `console.log(document.body);`

No hace falta instalar nada.

---

## Estructura de la charla

| # | Tema | Qué ver en la demo |
|---|------|--------------------|
| 1 | **Qué es el DOM** | Hero de la página + frase: “El DOM es lo que permite que JS cambie la página sin recargarla”. |
| 2 | **El árbol del DOM** | Árbol visual + instrucción para abrir consola y ver `document` / `document.body`. |
| 3 | **Seleccionar elementos** | getElementById, querySelector. Tip: “Si puedes seleccionarlo con CSS, puedes con querySelector”. |
| 4 | **Modificar contenido** | textContent (y mención breve de innerHTML / seguridad). |
| 5 | **Cambiar estilos** | classList.add / classList.toggle. “En proyectos reales casi siempre cambiamos clases”. |
| 6 | **Crear elementos** | createElement → contenido → appendChild. |
| 7 | **Eventos** | addEventListener("click", función). |
| 8 | **Event delegation** | Un listener en el padre, e.target para el hijo. Lista de ítems en la página. |
| 9 | **Mini demo** | To-Do list: agregar, clic = marcar hecha, doble clic = eliminar. |
| 10 | **Buenas prácticas** | Lista corta en la sección correspondiente. |
| 11 | **Q&A** | — |

---

## Qué demuestra el mini To-Do

- **Selección** de elementos (input, botón, lista).
- **Creación** de nodos (createElement, appendChild).
- **Modificación** (classList.toggle para “hecho”).
- **Eventos** (click, dblclick, keypress Enter).
- **Delegación** (un solo listener en la lista para todos los ítems).

---

## Estructura del proyecto

```
├── index.html      → Una sección por concepto + To-Do al final
├── css/styles.css  → Estilos (tema oscuro, tips, To-Do)
├── js/dom-demo.js  → Código comentado por sección
└── README.md       → Este archivo
```