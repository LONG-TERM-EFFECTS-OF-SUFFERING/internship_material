/**
 * DOM — Ver para entender
 * Demo para interns: claro, visual, práctico.
 */

document.addEventListener('DOMContentLoaded', () => {
  // Marca el checkbox "Desactivar (hacer por consola)" en una sección para que los botones
  // no hagan nada y puedas ejecutar tú el código en la consola durante la demo.
  function modoConsola(sectionId) {
    const el = document.getElementById('desactivar-' + sectionId);
    return el && el.checked;
  }

  // ============================================
  // 3. SELECCIONAR ELEMENTOS
  // getElementById, querySelector, querySelectorAll
  // ============================================
  const btnSeleccionar = document.getElementById('btn-seleccionar');
  const tituloEjemplo = document.getElementById('titulo-ejemplo');

  btnSeleccionar.addEventListener('click', () => {
    if (modoConsola('seleccionar')) return;
    console.log('Elemento seleccionado:', tituloEjemplo);
    console.log('textContent:', tituloEjemplo.textContent);
  });

  // ============================================
  // 4. CAMBIAR CONTENIDO
  // textContent (seguro) / innerHTML (cuidado)
  // ============================================
  const textoDinamico = document.getElementById('texto-dinamico');
  const inputTexto = document.getElementById('input-texto');
  const btnCambiarTexto = document.getElementById('btn-cambiar-texto');

  btnCambiarTexto.addEventListener('click', () => {
    if (modoConsola('cambiar-contenido')) return;
    textoDinamico.textContent = inputTexto.value || 'Hola interns 🚀';
  });

  // ============================================
  // 5. ESTILOS Y CLASES
  // En proyectos reales: clases, no estilos inline
  // ============================================
  const cajaEstilos = document.getElementById('caja-estilos');
  const btnClaseActive = document.getElementById('btn-clase-active');
  const btnClaseDark = document.getElementById('btn-clase-dark');

  btnClaseActive.addEventListener('click', () => {
    if (modoConsola('estilos')) return;
    cajaEstilos.classList.add('active');
  });

  btnClaseDark.addEventListener('click', () => {
    if (modoConsola('estilos')) return;
    cajaEstilos.classList.toggle('dark');
  });

  // ============================================
  // 6. CREAR ELEMENTOS
  // 1. Crear  2. Contenido  3. Agregar al DOM
  // ============================================
  const listaNodos = document.getElementById('lista-nodos');
  const inputNuevoItem = document.getElementById('input-nuevo-item');
  const btnAgregar = document.getElementById('btn-agregar');

  btnAgregar.addEventListener('click', () => {
    if (modoConsola('crear-elementos')) return;
    const texto = inputNuevoItem.value.trim() || 'Nuevo item';
    const li = document.createElement('li');
    li.textContent = texto;
    listaNodos.appendChild(li);
    inputNuevoItem.value = '';
  });

  // ============================================
  // 7. EVENTOS
  // addEventListener("click", función)
  // ============================================
  const btnEvento = document.getElementById('btn-evento');
  const mensajeEvento = document.getElementById('mensaje-evento');

  btnEvento.addEventListener('click', () => {
    if (modoConsola('eventos')) return;
    mensajeEvento.textContent = '¡Click detectado!';
    mensajeEvento.classList.remove('muted');
  });

  // ============================================
  // 8. EVENT DELEGATION
  // Un listener en el padre; e.target para saber el hijo
  // ============================================
  const listaDelegation = document.getElementById('lista-delegation');

  listaDelegation.addEventListener('click', (e) => {
    if (modoConsola('delegation')) return;
    if (e.target.tagName === 'LI') {
      console.log('Click en item:', e.target.textContent);
    }
  });

  // ============================================
  // 9. MINI DEMO: TO-DO LIST (DOM + Local Storage + Fetch)
  // ============================================
  const TODO_STORAGE_KEY = 'demo-todo-list';
  const todoInput = document.getElementById('todo-input');
  const todoAdd = document.getElementById('todo-add');
  const todoFetch = document.getElementById('todo-fetch');
  const todoList = document.getElementById('todo-list');

  function guardarTodoList() {
    if (!todoList) return;
    const items = [];
    for (const li of todoList.children) {
      items.push({ text: li.textContent, done: li.classList.contains('done') });
    }
    localStorage.setItem(TODO_STORAGE_KEY, JSON.stringify(items));
  }

  function cargarTodoList() {
    if (!todoList) return;
    try {
      const raw = localStorage.getItem(TODO_STORAGE_KEY);
      const items = raw ? JSON.parse(raw) : [];
      todoList.innerHTML = '';
      items.forEach((item) => {
        const li = document.createElement('li');
        li.textContent = item.text;
        if (item.done) li.classList.add('done');
        todoList.appendChild(li);
      });
    } catch (_) {
      todoList.innerHTML = '';
    }
  }

  function agregarTarea(texto) {
    if (!texto.trim() || !todoList) return;
    const li = document.createElement('li');
    li.textContent = texto;
    todoList.appendChild(li);
    todoInput.value = '';
    guardarTodoList();
  }

  cargarTodoList();

  todoAdd.addEventListener('click', () => {
    if (modoConsola('todo')) return;
    agregarTarea(todoInput.value);
  });
  todoInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      if (modoConsola('todo')) return;
      agregarTarea(todoInput.value);
    }
  });

  todoList.addEventListener('click', (e) => {
    if (modoConsola('todo')) return;
    if (e.target.tagName === 'LI') {
      e.target.classList.toggle('done');
      guardarTodoList();
    }
  });

  todoList.addEventListener('dblclick', (e) => {
    if (modoConsola('todo')) return;
    if (e.target.tagName === 'LI') {
      e.target.remove();
      guardarTodoList();
    }
  });

  if (todoFetch) {
    todoFetch.addEventListener('click', async () => {
      if (modoConsola('todo')) return;
      todoFetch.disabled = true;
      todoFetch.textContent = 'Cargando...';
      try {
        const res = await fetch('https://jsonplaceholder.typicode.com/todos?_limit=5');
        const data = await res.json();
        data.forEach((t) => agregarTarea(t.title));
      } catch (err) {
        console.error(err);
        agregarTarea('Error al cargar (revisa consola)');
      }
      todoFetch.disabled = false;
      todoFetch.textContent = 'Cargar tareas de ejemplo (Fetch)';
    });
  }

  // ============================================
  // FETCH API
  // ============================================
  const btnFetch = document.getElementById('btn-fetch');
  const fetchResult = document.getElementById('fetch-result');

  if (btnFetch && fetchResult) {
    btnFetch.addEventListener('click', async () => {
      if (modoConsola('fetch')) return;
      fetchResult.textContent = 'Cargando...';
      fetchResult.classList.remove('muted');
      try {
        const res = await fetch('https://jsonplaceholder.typicode.com/posts/1');
        const data = await res.json();
        fetchResult.textContent = `Title: ${data.title}`;
      } catch (err) {
        fetchResult.textContent = 'Error: ' + err.message;
      }
    });
  }

  // ============================================
  // LOCAL STORAGE
  // ============================================
  const STORAGE_KEY = 'demo-nombre';
  const storageInput = document.getElementById('storage-input');
  const btnStorageSave = document.getElementById('btn-storage-save');
  const btnStorageClear = document.getElementById('btn-storage-clear');
  const storageValue = document.getElementById('storage-value');

  function actualizarStorageUI() {
    const valor = localStorage.getItem(STORAGE_KEY);
    if (storageValue) {
      storageValue.textContent = valor ? `Guardado: ${valor}` : '(nada guardado)';
      storageValue.classList.toggle('muted', !valor);
    }
    if (storageInput && valor) storageInput.value = valor;
  }

  if (btnStorageSave && storageInput && storageValue) {
    actualizarStorageUI();
    btnStorageSave.addEventListener('click', () => {
      if (modoConsola('storage')) return;
      const v = storageInput.value.trim();
      if (v) localStorage.setItem(STORAGE_KEY, v);
      actualizarStorageUI();
    });
  }
  if (btnStorageClear && storageValue) {
    btnStorageClear.addEventListener('click', () => {
      if (modoConsola('storage')) return;
      localStorage.removeItem(STORAGE_KEY);
      if (storageInput) storageInput.value = '';
      actualizarStorageUI();
    });
  }

  console.log('DOM demo cargado. Prueba cada sección y abre document / document.body en consola.');
});
