# Chapter 02

**Enfoque:** variables/constantes, alcance (scope), expresiones, y primeras buenas prácticas.

- Evitamos `int.Parse()` porque lanza excepción ante entradas inválidas.
- Preferimos `int.TryParse()` para validar input de usuario.
- Empezamos a separar responsabilidades en métodos pequeños.
