# NumberLab (evolución por capítulos)

Este repositorio acompaña una serie didáctica de C# donde una app de consola va evolucionando capítulo a capítulo.

## Cómo usarlo

- Cada capítulo es un **tag** de git: `chapter-01` ... `chapter-12`.
- Para moverte a un capítulo:

```bash
git checkout chapter-05
```

> Nota: en este entorno no puedo compilar/ejecutar .NET, pero el código está escrito para un proyecto típico `net8.0`.

## Estructura

- `src/NumberLab/NumberLab.csproj`
- `src/NumberLab/Program.cs` y archivos auxiliares (van apareciendo con los capítulos)

## Línea de comandos (en capítulos avanzados)

Ejemplos:

```bash
NumberLab.exe -op max -numbers 1,2,3
NumberLab.exe -op avg -file datos.txt
NumberLab.exe                 # modo interactivo
```
