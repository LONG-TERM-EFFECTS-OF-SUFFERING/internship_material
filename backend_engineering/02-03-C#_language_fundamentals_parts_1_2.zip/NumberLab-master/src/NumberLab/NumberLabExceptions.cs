namespace NumberLab;

public class NumberSourceException : Exception
{
    public NumberSourceException(string message) : base(message) { }
}

public class NumberFileFormatException : NumberSourceException
{
    public NumberFileFormatException(string message) : base(message) { }
}
