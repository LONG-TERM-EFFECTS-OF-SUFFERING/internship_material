using System;

using NumberLab.Abstractions;

namespace NumberLab.Sources;

public sealed class CommandLineNumberSource : INumberSource
{
    private readonly string[] _args;
    private readonly List<int> _values = new();

    public CommandLineNumberSource(string[] args)
    {
        _args = args;
    }

    public string Name => "CommandLine";

    public event EventHandler<NumberReadEventArgs>? NumberRead;

    public IReadOnlyList<int> Values => _values;

    public void ReadValues()
    {
        _values.Clear();

        string? csv = ExtractCsv(_args);
        if (string.IsNullOrWhiteSpace(csv))
        {
            throw new NumberSourceException("No se encontró -numbers en la línea de comandos.");
        }

        int index = 0;
        foreach (string token in csv.Split(new[] { ',', ';', ' ' }, StringSplitOptions.RemoveEmptyEntries))
        {
            if (!int.TryParse(token.Trim(), out int value))
            {
                throw new NumberSourceException($"No pude convertir '{token}' a entero.");
            }

            _values.Add(value);
            NumberRead?.Invoke(this, new NumberReadEventArgs(value, index));
            index++;
        }

        if (_values.Count == 0)
        {
            throw new NumberSourceException("-numbers no contiene valores.");
        }
    }

    private static string? ExtractCsv(string[] args)
    {
        for (int i = 0; i < args.Length; i++)
        {
            if (args[i] is "-numbers" or "--numbers")
            {
                return (i + 1 < args.Length) ? args[i + 1] : null;
            }
        }

        return null;
    }
}
