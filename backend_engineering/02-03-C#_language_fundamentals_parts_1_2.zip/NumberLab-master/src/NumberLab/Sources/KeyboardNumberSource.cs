using System;
using NumberLab.Abstractions;
using NumberLab.Utils;

namespace NumberLab.Sources;

public sealed class KeyboardNumberSource : INumberSource
{
    private readonly List<int> _values = new();

    public string Name => "Keyboard";

    public event EventHandler<NumberReadEventArgs>? NumberRead;

    public IReadOnlyList<int> Values => _values;

    public void ReadValues()
    {
        _values.Clear();

        int count = ConsoleInput.ReadPositiveInt("¿Cuántos números quieres comparar? ");
        for (int i = 0; i < count; i++)
        {
            int value = ConsoleInput.ReadInt($"Número #{i + 1}: ");
            _values.Add(value);
            NumberRead?.Invoke(this, new NumberReadEventArgs(value, i));
        }
    }
}
