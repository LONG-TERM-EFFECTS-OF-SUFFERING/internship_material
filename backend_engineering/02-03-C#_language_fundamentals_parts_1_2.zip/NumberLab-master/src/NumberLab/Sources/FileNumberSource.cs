using System;
using System.IO;

using NumberLab.Abstractions;

namespace NumberLab.Sources;

public sealed class FileNumberSource : INumberSource
{
    private readonly string _path;
    private readonly List<int> _values = new();

    public FileNumberSource(string path)
    {
        _path = path;
    }

    public string Name => "File";

    public event EventHandler<NumberReadEventArgs>? NumberRead;

    public IReadOnlyList<int> Values => _values;

    public void ReadValues()
    {
        _values.Clear();

        if (!File.Exists(_path))
        {
            throw new NumberSourceException($"No existe el archivo '{_path}'.");
        }

        int lineNo = 0;
        int index = 0;

        foreach (string line in File.ReadLines(_path))
        {
            lineNo++;
            string trimmed = line.Trim();
            if (string.IsNullOrWhiteSpace(trimmed)) continue;
            if (trimmed.StartsWith('#')) continue;

            if (!int.TryParse(trimmed, out int value))
            {
                throw new NumberFileFormatException($"Línea {lineNo}: '{trimmed}' no es un entero válido.");
            }

            _values.Add(value);
            NumberRead?.Invoke(this, new NumberReadEventArgs(value, index, lineNo));
            index++;
        }

        if (_values.Count == 0)
        {
            throw new NumberSourceException("El archivo no contiene números.");
        }
    }
}
