using NumberLab.Abstractions;

namespace NumberLab.Services;

public static class NumberAnalyzer
{
    public static int FindMax(INumberSource source)
    {
        // Capítulo 08: el "algoritmo" no sabe si los números vienen de teclado, args o archivo.
        source.ReadValues();

        if (source.Values.Count == 0)
        {
            throw new NumberSourceException("No hay valores para analizar.");
        }

        int max = source.Values[0];
        foreach (int value in source.Values)
        {
            if (value > max) max = value;
        }

        return max;
    }
}
