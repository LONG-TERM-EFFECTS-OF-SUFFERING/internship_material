using System;
using System.Collections.Generic;
using System.Linq;

namespace NumberLab.Services;

public static class OperationCatalog
{
    // Capítulo 12: LINQ sobre colecciones (IEnumerable<T>). Mucho menos "ruido" que loops manuales.
    public static readonly IReadOnlyDictionary<string, Func<IReadOnlyList<int>, int>> Operations =
        new Dictionary<string, Func<IReadOnlyList<int>, int>>(StringComparer.OrdinalIgnoreCase)
        {
            ["max"] = values => values.Max(),
            ["min"] = values => values.Min(),
            ["sum"] = values => values.Sum(),
            ["range"] = values => values.Max() - values.Min(),
            ["count"] = values => values.Count,
            ["distinctcount"] = values => values.Distinct().Count(),
        };

    public static int Execute(string opName, IReadOnlyList<int> values)
    {
        if (values.Count == 0)
        {
            throw new NumberSourceException("No hay valores.");
        }

        if (!Operations.TryGetValue(opName, out var op))
        {
            throw new NumberSourceException($"Operación desconocida '{opName}'.");
        }

        return op(values);
    }
}
