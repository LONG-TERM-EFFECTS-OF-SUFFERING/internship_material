using System;
using System.Collections.Generic;

namespace NumberLab.Services;

public static class Algorithms
{
    // Capítulo 11: generics -> el mismo algoritmo funciona para int, double, DateTime, etc.
    public static T Max<T>(IEnumerable<T> items, IComparer<T>? comparer = null)
    {
        if (items is null) throw new ArgumentNullException(nameof(items));
        comparer ??= Comparer<T>.Default;

        using IEnumerator<T> it = items.GetEnumerator();
        if (!it.MoveNext())
        {
            throw new NumberSourceException("No hay valores.");
        }

        T best = it.Current;
        while (it.MoveNext())
        {
            if (comparer.Compare(it.Current, best) > 0)
            {
                best = it.Current;
            }
        }

        return best;
    }

    public static T Min<T>(IEnumerable<T> items, IComparer<T>? comparer = null)
    {
        if (items is null) throw new ArgumentNullException(nameof(items));
        comparer ??= Comparer<T>.Default;

        using IEnumerator<T> it = items.GetEnumerator();
        if (!it.MoveNext())
        {
            throw new NumberSourceException("No hay valores.");
        }

        T best = it.Current;
        while (it.MoveNext())
        {
            if (comparer.Compare(it.Current, best) < 0)
            {
                best = it.Current;
            }
        }

        return best;
    }
}
