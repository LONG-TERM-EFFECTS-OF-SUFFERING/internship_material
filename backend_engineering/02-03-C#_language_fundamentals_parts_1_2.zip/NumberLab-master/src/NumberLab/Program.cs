using System;
using System.IO;

using NumberLab.Abstractions;
using NumberLab.Services;
using NumberLab.Sources;

internal static class Program
{
    private const string AppName = "NumberLab";
    private const string Chapter = "12";

    private static int Main(string[] args)
    {
        PrintHeader();

       // Capítulo 10: nos suscribimos a un evento del proveedor de números (event).

        if (args.Length > 0 && (args[0] == "-h" || args[0] == "--help"))
        {
            PrintHelp();
            return 0;
        }

        try
        {
            string opName = GetOptionValueOrDefault(args, "max", "-op", "--op");
            INumberSource source = SelectSource(args);

            source.NumberRead += (_, e) =>
            {
                if (e.LineNumber is int ln)
                {
                    Console.WriteLine($"Leído[{e.Index}] (línea {ln}): {e.Value}");
                }
                else
                {
                    Console.WriteLine($"Leído[{e.Index}]: {e.Value}");
                }
            };

            source.ReadValues();
            int result = OperationCatalog.Execute(opName, source.Values);

            Console.WriteLine($"Fuente: {source.Name}");
            Console.WriteLine($"Operación: {opName}");
            Console.WriteLine($"Resultado: {result}");
            return 0;
        }
        catch (NumberSourceException ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
            return 1;
        }
        catch (UnauthorizedAccessException)
        {
            Console.WriteLine("Error: no tienes permisos para leer el archivo.");
            return 1;
        }
        catch (IOException ex)
        {
            Console.WriteLine($"Error de IO: {ex.Message}");
            return 1;
        }
    }

    private static void PrintHeader()
    {
        Console.WriteLine($"{AppName} - Chapter {Chapter}");
        Console.WriteLine(new string('-', 28));
    }

    private static void PrintHelp()
    {
        Console.WriteLine("Uso:");
        Console.WriteLine("  NumberLab.exe -op max -numbers 1,2,3,4");
        Console.WriteLine("  NumberLab.exe -op sum -file datos.txt");
        Console.WriteLine("  NumberLab.exe                      (modo interactivo; op=max)");
        Console.WriteLine();
        Console.WriteLine("Opciones:");
        Console.WriteLine("  -op       Operación: max | min | sum | range | count | distinctcount");
        Console.WriteLine("  -numbers  Lista separada por comas (ej: 1,2,3)");
        Console.WriteLine("  -file     Archivo de texto con un número por línea");
        Console.WriteLine("  -h|--help Mostrar ayuda");
    }

    private static INumberSource SelectSource(string[] args)
    {
        if (HasSwitch(args, "-numbers", "--numbers"))
        {
            return new CommandLineNumberSource(args);
        }

        if (TryGetOptionValue(args, out string path, "-file", "--file"))
        {
            return new FileNumberSource(path);
        }

        return new KeyboardNumberSource();
    }

    private static bool HasSwitch(string[] args, params string[] names)
    {
        foreach (string a in args)
        {
            foreach (string n in names)
            {
                if (a == n) return true;
            }
        }
        return false;
    }

    private static bool TryGetOptionValue(string[] args, out string value, params string[] names)
    {
        value = string.Empty;

        for (int i = 0; i < args.Length; i++)
        {
            foreach (string name in names)
            {
                if (args[i] == name)
                {
                    if (i + 1 >= args.Length)
                    {
                        throw new NumberSourceException($"Falta el valor después de {name}.");
                    }

                    value = args[i + 1];
                    return true;
                }
            }
        }

        return false;
    }

    private static string GetOptionValueOrDefault(string[] args, string defaultValue, params string[] names)
    {
        return TryGetOptionValue(args, out string value, names) ? value : defaultValue;
    }
}
