namespace NumberLab.Utils;

public static class ConsoleInput
{
    public static int ReadPositiveInt(string prompt)
    {
        while (true)
        {
            int value = ReadInt(prompt);
            if (value > 0) return value;
            Console.WriteLine("Debe ser un entero positivo (> 0). Intenta otra vez.");
        }
    }

    public static int ReadInt(string prompt)
    {
        while (true)
        {
            Console.Write(prompt);
            string? raw = Console.ReadLine();
            if (int.TryParse(raw, out int value)) return value;

            Console.WriteLine("Entrada inválida. Escribe un entero (ej: 42, -7)." );
        }
    }
}
