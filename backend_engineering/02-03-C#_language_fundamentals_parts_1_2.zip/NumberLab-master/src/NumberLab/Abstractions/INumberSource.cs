using System;
using System.Collections.Generic;

namespace NumberLab.Abstractions;

public interface INumberSource
{
    string Name { get; }

    /// <summary>Se dispara cada vez que se lee un número.</summary>
    event EventHandler<NumberReadEventArgs>? NumberRead;

    /// <summary>Lee/carga valores a la propiedad Values.</summary>
    void ReadValues();

    /// <summary>Valores cargados por ReadValues().</summary>
    IReadOnlyList<int> Values { get; }
}
