using System;

namespace NumberLab.Abstractions;

public sealed class NumberReadEventArgs : EventArgs
{
    public NumberReadEventArgs(int value, int index, int? lineNumber = null)
    {
        Value = value;
        Index = index;
        LineNumber = lineNumber;
    }

    public int Value { get; }
    public int Index { get; }

    /// <summary>Solo aplica a fuentes basadas en archivo.</summary>
    public int? LineNumber { get; }
}
