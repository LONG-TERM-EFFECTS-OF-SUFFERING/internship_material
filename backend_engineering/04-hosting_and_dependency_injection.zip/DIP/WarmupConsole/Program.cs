﻿using System.Drawing;
using Warmup;

namespace WarmupConsole
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<IShape> shapes =
            [
                new Circle(5)
            ];

            foreach (var shape in shapes)
            {
                Console.WriteLine($"Type: {shape.GetType().Name}");
                Console.WriteLine($"Area: {shape.GetArea():F2}");

                Console.WriteLine();
            }
        }
    }
}
