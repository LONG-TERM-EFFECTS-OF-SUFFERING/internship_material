﻿using Checkout;
using Microsoft.Extensions.DependencyInjection;

namespace ConsoleApp
{
    public class Program
    {
        static void Main(string[] args)
        {
            var services = new ServiceCollection();

            services.AddTransient<ICheckoutService, CheckoutService>();
            services.AddSingleton<IInventoryService, InventoryService>();
            services.AddSingleton<IPaymentGateway, PaymentGateway>();
            services.AddSingleton<IOrderRepository, OrderRepository>();
            services.AddSingleton<INotification, EmailNotification>();
            services.AddSingleton<IIdGenerator, GuidIdGenerator>();
            services.AddTransient<App>();

            using var provider = services.BuildServiceProvider();
                        
            var app = provider.GetRequiredService<App>();
            app.RunCheckout();
        }

        private static void GetRequiredServiceWhenAddedAsScoped(IServiceProvider provider)
        {
            Console.WriteLine("=== Scope 1 ===");
            using var scope1 = provider.CreateScope();
            var app1 = scope1.ServiceProvider.GetRequiredService<App>();
            var app2 = scope1.ServiceProvider.GetRequiredService<App>();
            Console.WriteLine($"Scope1 - First resolve:  {app1.Id}");
            Console.WriteLine($"Scope1 - Second resolve: {app2.Id}");

            Console.WriteLine();
            Console.WriteLine("=== Scope 2 ===");
            using var scope2 = provider.CreateScope();
            var app3 = scope2.ServiceProvider.GetRequiredService<App>();
            Console.WriteLine($"Scope2 - First resolve:  {app3.Id}");
        }

        private static void GetRequiredServiceWhenAddedAsSingleton(IServiceProvider provider)
        {
            var app1 = provider.GetRequiredService<App>();
            var app2 = provider.GetRequiredService<App>();

            Console.WriteLine($"Singleton - First resolve:  {app1.Id}");
            Console.WriteLine($"Singleton - Second resolve: {app2.Id}");
        }
    }
}
