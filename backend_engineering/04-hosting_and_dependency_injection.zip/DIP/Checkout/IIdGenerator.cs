﻿namespace Checkout
{
    public interface IIdGenerator
    {
        string NewOrderId();
    }
}
