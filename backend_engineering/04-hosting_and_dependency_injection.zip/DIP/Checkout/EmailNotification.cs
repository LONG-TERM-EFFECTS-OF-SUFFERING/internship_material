﻿namespace Checkout
{
    public class EmailNotification : INotification
    {
        public void Send(string customerId, string subject, string body)
        {
            Console.WriteLine($"[Email] To={customerId}");
            Console.WriteLine($"  Subject: {subject}");
            Console.WriteLine($"  Body: {body}");
        }
    }
}
