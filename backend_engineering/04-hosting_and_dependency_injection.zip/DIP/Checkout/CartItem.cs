﻿namespace Checkout
{
    public class CartItem
    {
        public string Sku { get; }
        public int Quantity { get; }
        public Money UnitPrice { get; }

        public CartItem(string sku, int quantity, Money unitPrice)
        {
            if (string.IsNullOrWhiteSpace(sku))
                throw new ArgumentException("SKU is required.");

            if (quantity <= 0)
                throw new ArgumentException("Quantity must be greater than zero.");

            UnitPrice = unitPrice ?? throw new ArgumentNullException(nameof(unitPrice));

            Sku = sku;
            Quantity = quantity;
        }

        public Money Subtotal()
        {
            return UnitPrice.Multiply(Quantity);
        }
    }
}
