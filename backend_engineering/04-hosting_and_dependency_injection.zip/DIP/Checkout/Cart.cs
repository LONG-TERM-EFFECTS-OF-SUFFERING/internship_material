﻿namespace Checkout
{
    public class Cart
    {
        private readonly List<CartItem> _items = [];

        public string CustomerId { get; }
        public IReadOnlyCollection<CartItem> Items => _items.AsReadOnly();

        public Cart(string customerId)
        {
            if (string.IsNullOrWhiteSpace(customerId))
                throw new ArgumentException("CustomerId is required.");

            CustomerId = customerId;
        }

        public void AddItem(CartItem item)
        {
            _items.Add(item);
        }

        public Money Total()
        {
            if (!_items.Any())
                return new Money(0, "USD"); // simplification

            var total = new Money(0, _items.First().UnitPrice.Currency);

            foreach (var item in _items)
            {
                total = Money.Add(total, item.Subtotal());
            }

            return total;
        }
    }
}
