﻿namespace Checkout
{
    public interface ICheckoutService
    {
        (bool Success, string Message, string? OrderId) Checkout(Cart cart, string paymentMethodToken);
    }
}
