﻿
namespace Checkout
{
    public class InventoryService : IInventoryService
    {
        public bool ReserveItems(IReadOnlyCollection<CartItem> items)
        {
            Console.WriteLine($"[Inventory] Reserving {items.Count} items...");
            foreach (var i in items)
                Console.WriteLine($"  - {i.Sku} x{i.Quantity}");
            return true; // demo: always succeed
        }
    }
}
