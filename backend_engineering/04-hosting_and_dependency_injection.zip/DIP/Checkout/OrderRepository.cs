﻿namespace Checkout
{
    public class OrderRepository: IOrderRepository
    {
        public void Add(Order order)
        {
            Console.WriteLine($"[Orders] ADD {order.OrderId} status={order.Status} total={order.Total.Amount} {order.Total.Currency}");
        }

        public void Update(Order order)
        {
            Console.WriteLine($"[Orders] UPDATE {order.OrderId} status={order.Status}");
        }
    }
}
