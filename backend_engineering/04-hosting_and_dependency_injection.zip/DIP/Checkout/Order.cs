﻿namespace Checkout
{
    public class Order
    {
        public string OrderId { get; }
        public string CustomerId { get; }
        public IReadOnlyCollection<CartItem> Items { get; }
        public Money Total { get; }
        public OrderStatus Status { get; private set; }

        public Order(string orderId, string customerId, IEnumerable<CartItem> items, Money total)
        {
            OrderId = orderId ?? throw new ArgumentNullException(nameof(orderId));
            CustomerId = customerId ?? throw new ArgumentNullException(nameof(customerId));
            Items = items.ToList().AsReadOnly();
            Total = total ?? throw new ArgumentNullException(nameof(total));

            Status = OrderStatus.Pending;
        }

        public void MarkPaid()
        {
            if (Status != OrderStatus.Pending)
                throw new InvalidOperationException("Only pending orders can be marked as paid.");

            Status = OrderStatus.Paid;
        }

        public void MarkFailed()
        {
            if (Status != OrderStatus.Pending)
                throw new InvalidOperationException("Only pending orders can be marked as failed.");

            Status = OrderStatus.Failed;
        }
    }
}
