﻿namespace Checkout
{
    public class PaymentGateway: IPaymentGateway
    {
        public PaymentResult Charge(string customerId, Money amount, string paymentMethodToken)
        {
            Console.WriteLine($"[Payments] Charging {customerId}: {amount.Amount} {amount.Currency} (token={paymentMethodToken})");
            return new PaymentResult(true, "txn_demo_001", null);
        }
    }
}
