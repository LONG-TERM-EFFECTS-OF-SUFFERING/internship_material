﻿namespace Checkout
{
    public class GuidIdGenerator : IIdGenerator
    {
        public string NewOrderId() => $"ORDER-{Guid.NewGuid():N}".ToUpperInvariant();
    }
}
