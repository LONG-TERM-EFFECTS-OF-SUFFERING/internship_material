﻿namespace Checkout
{
    public interface IPaymentGateway
    {
        PaymentResult Charge(string customerId, Money amount, string paymentMethodToken);
    }
}
