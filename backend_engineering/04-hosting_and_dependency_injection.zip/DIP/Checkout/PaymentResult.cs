﻿namespace Checkout
{
    public class PaymentResult
    {
        public bool Success { get; }
        public string TransactionId { get; }
        public string? FailureReason { get; }

        public PaymentResult(bool success, string transactionId, string? failureReason)
        {
            Success = success;
            TransactionId = transactionId;
            FailureReason = failureReason;
        }
    }
}
