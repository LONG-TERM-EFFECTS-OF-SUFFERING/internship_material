﻿namespace Checkout
{
    public class App
    {
        public Guid Id { get; } = Guid.NewGuid();

        private readonly ICheckoutService _checkout;

        public App(ICheckoutService checkout)
        {
            _checkout = checkout;
        }

        public void RunCheckout()
        {
            var cart = new Cart("cust-123");
            cart.AddItem(new CartItem("SKU-KEYBOARD", 1, new Money(45.50m, "USD")));
            cart.AddItem(new CartItem("SKU-MOUSE", 2, new Money(12.25m, "USD")));

            var total = cart.Total();
            Console.WriteLine($"Cart total: {total.Amount} {total.Currency}");
            Console.WriteLine();

            var (Success, Message, OrderId) = _checkout.Checkout(cart, "pm_demo_token");

            Console.WriteLine();
            Console.WriteLine($"Result: success={Success}, message='{Message}', orderId={OrderId}");
        }
    }
}
