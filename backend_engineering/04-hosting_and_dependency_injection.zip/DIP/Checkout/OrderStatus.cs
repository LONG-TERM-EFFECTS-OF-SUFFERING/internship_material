﻿namespace Checkout
{
    public enum OrderStatus
    {
        Pending,
        Paid,
        Failed
    }
}
