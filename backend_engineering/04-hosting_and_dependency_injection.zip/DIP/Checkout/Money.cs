﻿namespace Checkout
{
    public class Money
    {
        public decimal Amount { get; }
        public string Currency { get; }

        public Money(decimal amount, string currency)
        {
            if (amount < 0)
                throw new ArgumentException("Amount cannot be negative.");

            if (string.IsNullOrWhiteSpace(currency))
                throw new ArgumentException("Currency is required.");

            Amount = amount;
            Currency = currency;
        }

        public Money Multiply(int quantity)
        {
            if (quantity < 0)
                throw new ArgumentException("Quantity cannot be negative.");

            return new Money(Amount * quantity, Currency);
        }

        public static Money Add(Money a, Money b)
        {
            if (a.Currency != b.Currency)
                throw new InvalidOperationException("Cannot add different currencies.");

            return new Money(a.Amount + b.Amount, a.Currency);
        }
    }
}
