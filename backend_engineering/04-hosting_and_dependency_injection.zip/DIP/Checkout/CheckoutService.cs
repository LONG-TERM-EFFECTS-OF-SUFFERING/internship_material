﻿namespace Checkout
{
    public class CheckoutService : ICheckoutService
    {
        private readonly IInventoryService _inventory;
        private readonly IPaymentGateway _payments;
        private readonly IOrderRepository _orders;
        private readonly INotification _email;
        private readonly IIdGenerator _ids;

        public CheckoutService(
            IInventoryService inventory,
            IPaymentGateway payments,
            IOrderRepository orders,
            INotification email,
            IIdGenerator ids)
        {
            _inventory = inventory;
            _payments = payments;
            _orders = orders;
            _email = email;
            _ids = ids;
        }
        public (bool Success, string Message, string? OrderId) Checkout(Cart cart, string paymentMethodToken)
        {
            if (cart.Items.Count == 0)
                return (false, "Cart is empty.", null);

            if (!_inventory.ReserveItems(cart.Items))
                return (false, "Some items are out of stock.", null);

            var orderId = _ids.NewOrderId();
            var order = new Order(orderId, cart.CustomerId, cart.Items, cart.Total());

            _orders.Add(order);

            var payment = _payments.Charge(cart.CustomerId, order.Total, paymentMethodToken);

            if (!payment.Success)
            {
                order.MarkFailed();
                _orders.Update(order);
                return (false, $"Payment failed: {payment.FailureReason}", orderId);
            }

            order.MarkPaid();
            _orders.Update(order);

            _email.Send(
                cart.CustomerId,
                $"Order {orderId} confirmed",
                $"Total paid: {order.Total.Amount} {order.Total.Currency}"
            );

            return (true, "Checkout completed.", orderId);
        }
    }
}
