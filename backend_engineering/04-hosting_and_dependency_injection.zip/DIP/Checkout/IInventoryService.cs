﻿namespace Checkout
{
    public interface IInventoryService
    {
        bool ReserveItems(IReadOnlyCollection<CartItem> items);
    }
}
