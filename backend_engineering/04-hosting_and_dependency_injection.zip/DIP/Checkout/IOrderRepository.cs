﻿namespace Checkout
{
    public interface IOrderRepository
    {
        void Add(Order order);
        void Update(Order order);
    }
}
