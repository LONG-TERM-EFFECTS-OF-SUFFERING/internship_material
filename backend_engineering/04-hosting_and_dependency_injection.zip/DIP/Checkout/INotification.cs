﻿namespace Checkout
{
    public interface INotification
    {
        void Send(string customerId, string subject, string body);
    }
}
