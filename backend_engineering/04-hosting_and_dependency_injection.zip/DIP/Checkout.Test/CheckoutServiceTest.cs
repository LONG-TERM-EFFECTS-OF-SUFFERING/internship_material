﻿using Moq;

namespace Checkout.Test
{
    public class CheckoutServiceTest
    {
        private readonly Mock<IInventoryService> _inventoryService;
        private readonly Mock<IPaymentGateway> _paymentGateway;
        private readonly Mock<IOrderRepository> _orderRepository;
        private readonly Mock<INotification> _emailNotification;
        private readonly Mock<IIdGenerator> _idGenerator;
        private readonly CheckoutService _checkoutService;

        public CheckoutServiceTest()
        {
            _inventoryService = new Mock<IInventoryService>();
            _paymentGateway = new Mock<IPaymentGateway>();
            _orderRepository = new Mock<IOrderRepository>();
            _emailNotification = new Mock<INotification>();
            _idGenerator = new Mock<IIdGenerator>();
           
            _checkoutService = new CheckoutService(_inventoryService.Object, _paymentGateway.Object, _orderRepository.Object, _emailNotification.Object, _idGenerator.Object);
        }

        private static Cart BuildSampleCart()
        {
            var cart = new Cart("cust-123");
            cart.AddItem(new CartItem("SKU-KEYBOARD", 1, new Money(45.50m, "USD")));
            cart.AddItem(new CartItem("SKU-MOUSE", 2, new Money(12.25m, "USD")));
            return cart;
        }

        [Fact]
        public void Checkout_ReturnsFailure_WhenCartIsEmpty()
        {
            var emptyCart = new Cart("cust-empty");

            var (success, message, orderId) = _checkoutService.Checkout(emptyCart, "token");

            Assert.False(success);
            Assert.Equal("Cart is empty.", message);
            Assert.Null(orderId);

            _inventoryService.Verify(i => i.ReserveItems(It.IsAny<IReadOnlyCollection<CartItem>>()), Times.Never);
            _idGenerator.Verify(i => i.NewOrderId(), Times.Never);
            _orderRepository.Verify(o => o.Add(It.IsAny<Order>()), Times.Never);
            _paymentGateway.Verify(p => p.Charge(It.IsAny<string>(), It.IsAny<Money>(), It.IsAny<string>()), Times.Never);
            _emailNotification.Verify(e => e.Send(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Never);
        }

        [Fact]
        public void Checkout_ReturnsFailure_WhenReserveItemsFails()
        {
            var cart = BuildSampleCart();

            _inventoryService.Setup(i => i.ReserveItems(It.IsAny<IReadOnlyCollection<CartItem>>())).Returns(false);

            var (success, message, orderId) = _checkoutService.Checkout(cart, "token");

            Assert.False(success);
            //TODO
            Assert.Null(orderId);
        }

        [Fact]
        public void Checkout_Succeeds_WhenAllStepsPass_AndSendsNotification()
        {
            var cart = BuildSampleCart();
            _inventoryService.Setup(i => i.ReserveItems(It.IsAny<IReadOnlyCollection<CartItem>>())).Returns(true);
            _idGenerator.Setup(i => i.NewOrderId()).Returns("order-999");

            Order? orderAdded = null;
            _orderRepository.Setup(o => o.Add(It.IsAny<Order>())).Callback<Order>(o => orderAdded = o);

            _paymentGateway.Setup(p => p.Charge(cart.CustomerId, It.IsAny<Money>(), "pm_demo_token"))
                    .Returns(new PaymentResult(true, "txn-1", null));

            var (success, message, orderId) = _checkoutService.Checkout(cart, "pm_demo_token");

            Assert.True(success);
            Assert.Equal("Checkout completed.", message);
            Assert.Equal("order-999", orderId);

            Assert.NotNull(orderAdded);
            Assert.Equal(OrderStatus.Paid, orderAdded!.Status);
        }
    }
}
