﻿namespace Warmup
{
    public interface IShape
    {
        double GetArea();
    }
}
