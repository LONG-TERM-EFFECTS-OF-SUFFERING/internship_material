// ============================================================
// Async Programming Demos — Internship Training
// ============================================================
// Run a specific demo by uncommenting the line you need,
// or pass the demo name as a command-line argument.
//
// Usage:  dotnet run -- <demo-name>
//
// Available demos:
//   server-comparison     Block 1 — Blocking vs Async server comparison
//   thread-id             Block 2 — Thread ID before/after await
//   trace-async-flow      Block 2 — Step-by-step async flow trace
//   sequential-concurrent Block 3 — Sequential vs Concurrent awaits
//   patterns              Block 3 — Fan-out, Throttling, Retry
//   exception-demos       Block 4 — Exception handling scenarios
//   broken-code           Block 4 — The broken async void code
//   deadlock              Block 5 — Classic deadlock demonstration
//   io-vs-cpu             Block 5 — I/O-bound vs CPU-bound
// ============================================================

using Demos.Block1_Foundations;
using Demos.Block2_UnderTheHood;
using Demos.Block3_TAP;
using Demos.Block4_Exceptions;
using Demos.Block5_Deadlocks;

var demo = args.Length > 0 ? args[0] : "menu";

switch (demo.ToLower())
{
    case "server-comparison":
        await ServerComparison.RunAsync();
        break;
    case "thread-id":
        await ThreadIdDemo.RunAsync();
        break;
    case "trace-async-flow":
        await TraceAsyncFlow.RunAsync();
        break;
    case "sequential-concurrent":
        await SequentialVsConcurrent.RunAsync();
        break;
    case "patterns":
        await PatternsDemo.RunAsync();
        break;
    case "exception-demos":
        await ExceptionDemos.RunAsync();
        break;
    case "broken-code":
        await BrokenCode.RunAsync();
        break;
    case "deadlock":
        DeadlockDemo.Run();
        break;
    case "io-vs-cpu":
        await IoBoundVsCpuBound.RunAsync();
        break;
    default:
        Console.WriteLine("=== Async Programming Demos ===");
        Console.WriteLine();
        Console.WriteLine("Available demos:");
        Console.WriteLine("  dotnet run -- server-comparison");
        Console.WriteLine("  dotnet run -- thread-id");
        Console.WriteLine("  dotnet run -- trace-async-flow");
        Console.WriteLine("  dotnet run -- sequential-concurrent");
        Console.WriteLine("  dotnet run -- patterns");
        Console.WriteLine("  dotnet run -- exception-demos");
        Console.WriteLine("  dotnet run -- broken-code");
        Console.WriteLine("  dotnet run -- deadlock");
        Console.WriteLine("  dotnet run -- io-vs-cpu");
        break;
}
