namespace Demos.Block2_UnderTheHood;

/// <summary>
/// Slide 16 — Where Does the Method Resume?
/// Proves that the thread ID changes after an await.
/// </summary>
public static class ThreadIdDemo
{
    public static async Task RunAsync()
    {
        Console.WriteLine("=== Thread ID Before & After Await ===\n");

        for (int i = 1; i <= 3; i++)
        {
            Console.WriteLine($"--- Iteration {i} ---");

            var beforeId = Thread.CurrentThread.ManagedThreadId;
            Console.WriteLine($"  Before await — Thread ID: {beforeId}");

            await Task.Delay(500); // true async pause

            var afterId = Thread.CurrentThread.ManagedThreadId;
            Console.WriteLine($"  After  await — Thread ID: {afterId}");

            if (beforeId != afterId)
                Console.WriteLine($"  ✅ Different thread! Proof that execution resumed on another thread.\n");
            else
                Console.WriteLine($"  ⚠️ Same thread (can happen, but not guaranteed).\n");
        }

        Console.WriteLine("--- Key takeaway ---");
        Console.WriteLine("After an await, the continuation may run on a DIFFERENT thread.");
        Console.WriteLine("In a console app, the ThreadPool picks any available thread.");
        Console.WriteLine("In WPF/WinForms, the UI SynchronizationContext forces it back to the UI thread.");
    }
}
