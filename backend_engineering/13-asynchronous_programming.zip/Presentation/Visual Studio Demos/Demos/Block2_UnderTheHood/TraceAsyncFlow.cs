namespace Demos.Block2_UnderTheHood;

/// <summary>
/// Slide 23 — Exercise: Trace the Async Flow (Presenter Walkthrough)
/// Walk through this with the audience, explaining each step.
/// </summary>
public static class TraceAsyncFlow
{
    public static async Task RunAsync()
    {
        Console.WriteLine("=== Trace the Async Flow ===\n");
        Console.WriteLine("Watch the steps and thread IDs as we go...\n");

        await LoadAndDisplayAsync();

        Console.WriteLine("\n--- What just happened? ---");
        Console.WriteLine("1. Step 1 ran on the original thread.");
        Console.WriteLine("2. At 'await GetFromApiAsync()', the method PAUSED.");
        Console.WriteLine("   → State machine saved state = 0, registered MoveNext as continuation.");
        Console.WriteLine("   → Thread was RELEASED back to the pool.");
        Console.WriteLine("3. When the API call completed, MoveNext ran (possibly on a different thread).");
        Console.WriteLine("   → State machine advanced to state 1, executed Step 2.");
        Console.WriteLine("4. At 'await Task.Delay(500)', the method PAUSED again.");
        Console.WriteLine("   → State machine saved state = 1, registered another continuation.");
        Console.WriteLine("5. When the delay completed, MoveNext ran again → Step 3.");
    }

    private static async Task LoadAndDisplayAsync()
    {
        Console.WriteLine($"  Step 1 — Thread ID: {Thread.CurrentThread.ManagedThreadId}");    // line A

        var data = await GetFromApiAsync();                                                     // line B

        Console.WriteLine($"  Step 2 — Thread ID: {Thread.CurrentThread.ManagedThreadId}, Data: {data}");  // line C

        await Task.Delay(500);                                                                  // line D

        Console.WriteLine($"  Step 3 — Thread ID: {Thread.CurrentThread.ManagedThreadId}");    // line E
    }

    private static async Task<string> GetFromApiAsync()
    {
        Console.WriteLine($"  [GetFromApiAsync] Starting... Thread ID: {Thread.CurrentThread.ManagedThreadId}");
        await Task.Delay(1000); // simulate API call
        Console.WriteLine($"  [GetFromApiAsync] Done!       Thread ID: {Thread.CurrentThread.ManagedThreadId}");
        return "API Response Data";
    }
}
