using System.Diagnostics;

namespace Demos.Block3_TAP;

/// <summary>
/// Slides 31–32 — Fan-Out, Throttling & Retry patterns
/// </summary>
public static class PatternsDemo
{
    public static async Task RunAsync()
    {
        Console.WriteLine("=== Practical Patterns: Fan-Out, Throttling, Retry ===\n");

        // --- FAN-OUT ---
        Console.WriteLine("1) FAN-OUT — Fire multiple tasks at once:");
        var sw = Stopwatch.StartNew();

        var ids = new[] { 1, 2, 3, 4, 5 };
        var tasks = ids.Select(id => LoadItemAsync(id));
        var items = await Task.WhenAll(tasks);

        sw.Stop();
        Console.WriteLine($"   Loaded {items.Length} items in {sw.ElapsedMilliseconds} ms");
        Console.WriteLine($"   (All ran concurrently — ~500 ms, not 5 × 500 ms)\n");

        // --- THROTTLING ---
        Console.WriteLine("2) THROTTLING — Limit to 2 concurrent tasks:");
        sw.Restart();

        using var sem = new SemaphoreSlim(2);
        var throttledTasks = ids.Select(async id =>
        {
            await sem.WaitAsync();
            try
            {
                Console.WriteLine($"   [Item {id}] Starting (Thread {Thread.CurrentThread.ManagedThreadId})");
                return await LoadItemAsync(id);
            }
            finally
            {
                sem.Release();
            }
        });
        var throttledItems = await Task.WhenAll(throttledTasks);

        sw.Stop();
        Console.WriteLine($"   Loaded {throttledItems.Length} items in {sw.ElapsedMilliseconds} ms");
        Console.WriteLine($"   (Only 2 at a time — takes longer but controls resource usage)\n");

        // --- RETRY ---
        Console.WriteLine("3) RETRY — Retry with exponential backoff:");
        try
        {
            var result = await RetryAsync(maxAttempts: 3);
            Console.WriteLine($"   Final result: {result}\n");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"   All retries failed: {ex.Message}\n");
        }

        Console.WriteLine("--- Key takeaway ---");
        Console.WriteLine("Fan-out for speed, throttle for resource control, retry for resilience.");
    }

    private static async Task<string> LoadItemAsync(int id)
    {
        await Task.Delay(500); // simulate I/O
        return $"Item-{id}";
    }

    private static int _attempt = 0;

    private static async Task<string> RetryAsync(int maxAttempts)
    {
        _attempt = 0;
        for (int attempt = 1; ; attempt++)
        {
            try
            {
                return await UnreliableCallAsync(attempt, maxAttempts);
            }
            catch (Exception ex) when (attempt < maxAttempts)
            {
                var delay = 300 * attempt;
                Console.WriteLine($"   Attempt {attempt} failed: {ex.Message} — retrying in {delay} ms...");
                await Task.Delay(delay);
            }
        }
    }

    private static async Task<string> UnreliableCallAsync(int attempt, int maxAttempts)
    {
        await Task.Delay(200); // simulate call
        _attempt++;
        if (_attempt < maxAttempts)
            throw new HttpRequestException($"Server returned 503 (attempt {attempt})");
        return "Success on final attempt!";
    }
}
