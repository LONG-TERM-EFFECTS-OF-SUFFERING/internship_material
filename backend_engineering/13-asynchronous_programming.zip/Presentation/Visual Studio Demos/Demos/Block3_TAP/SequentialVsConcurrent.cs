using System.Diagnostics;

namespace Demos.Block3_TAP;

/// <summary>
/// Slide 27 — Sequential vs Concurrent Awaits
/// Run both approaches and compare elapsed time.
/// </summary>
public static class SequentialVsConcurrent
{
    public static async Task RunAsync()
    {
        Console.WriteLine("=== Sequential vs Concurrent Awaits ===\n");

        // --- SEQUENTIAL ---
        Console.WriteLine("1) SEQUENTIAL — await one after the other:");
        var sw = Stopwatch.StartNew();

        var a = await SimulateApiCallAsync("API-A", 1500);
        var b = await SimulateApiCallAsync("API-B", 1500);

        sw.Stop();
        Console.WriteLine($"   Results: {a}, {b}");
        Console.WriteLine($"   Total time: {sw.ElapsedMilliseconds} ms  (≈ A + B = 3000 ms)\n");

        // --- CONCURRENT ---
        Console.WriteLine("2) CONCURRENT — start both, then await:");
        sw.Restart();

        var taskA = SimulateApiCallAsync("API-A", 1500);
        var taskB = SimulateApiCallAsync("API-B", 1500);
        var results = await Task.WhenAll(taskA, taskB);

        sw.Stop();
        Console.WriteLine($"   Results: {results[0]}, {results[1]}");
        Console.WriteLine($"   Total time: {sw.ElapsedMilliseconds} ms  (≈ max(A, B) = 1500 ms)\n");

        Console.WriteLine("--- Key takeaway ---");
        Console.WriteLine("Concurrency happens at TASK CREATION, not at await.");
        Console.WriteLine("Start independent tasks first, then await them together.");
    }

    private static async Task<string> SimulateApiCallAsync(string name, int delayMs)
    {
        Console.WriteLine($"   [{name}] Started on Thread {Thread.CurrentThread.ManagedThreadId}");
        await Task.Delay(delayMs);
        Console.WriteLine($"   [{name}] Completed on Thread {Thread.CurrentThread.ManagedThreadId}");
        return $"{name}-result";
    }
}
