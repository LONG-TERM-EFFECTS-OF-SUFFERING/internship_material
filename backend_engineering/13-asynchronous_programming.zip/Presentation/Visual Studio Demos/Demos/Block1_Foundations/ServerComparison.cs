namespace Demos.Block1_Foundations;

/// <summary>
/// Slide 12 — Why Async Matters on Servers
/// Shows the difference between blocking and async approaches.
/// </summary>
public static class ServerComparison
{
    public static async Task RunAsync()
    {
        Console.WriteLine("=== Server Comparison: Blocking vs Async ===\n");

        // Simulate a "database call" that takes 2 seconds
        // In real life this would be HttpClient, EF Core, etc.

        // --- BLOCKING approach ---
        Console.WriteLine("1) BLOCKING approach (.Result):");
        Console.WriteLine("   The thread is STUCK for 2 seconds. It can't do anything else.\n");

        var sw = System.Diagnostics.Stopwatch.StartNew();
        var blockedResult = SimulateDbCallAsync().Result; // BAD — blocks the thread
        sw.Stop();
        Console.WriteLine($"   Result: {blockedResult}");
        Console.WriteLine($"   Thread was blocked for: {sw.ElapsedMilliseconds} ms");
        Console.WriteLine($"   Thread ID (same throughout): {Thread.CurrentThread.ManagedThreadId}\n");

        // --- ASYNC approach ---
        Console.WriteLine("2) ASYNC approach (await):");
        Console.WriteLine("   The thread is RELEASED during the wait. It can serve other requests.\n");

        sw.Restart();
        Console.WriteLine($"   Thread ID before await: {Thread.CurrentThread.ManagedThreadId}");
        var asyncResult = await SimulateDbCallAsync(); // GOOD — releases the thread
        sw.Stop();
        Console.WriteLine($"   Thread ID after await:  {Thread.CurrentThread.ManagedThreadId}");
        Console.WriteLine($"   Result: {asyncResult}");
        Console.WriteLine($"   Elapsed: {sw.ElapsedMilliseconds} ms");

        Console.WriteLine("\n--- Key takeaway ---");
        Console.WriteLine("Both take the same wall-clock time, but the async version");
        Console.WriteLine("frees the thread to handle OTHER work while waiting.");
        Console.WriteLine("On a server, this means thousands more concurrent requests.");
    }

    private static async Task<string> SimulateDbCallAsync()
    {
        await Task.Delay(2000); // simulate 2-second I/O operation
        return "Data from database";
    }
}
