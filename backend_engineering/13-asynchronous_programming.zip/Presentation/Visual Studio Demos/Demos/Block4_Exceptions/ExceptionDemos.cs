namespace Demos.Block4_Exceptions;

/// <summary>
/// Slides 35–40 — Exception Handling in Async Code
/// Demonstrates how exceptions behave with await, .Result, async void, etc.
/// </summary>
public static class ExceptionDemos
{
    public static async Task RunAsync()
    {
        Console.WriteLine("=== Exception Handling in Async Code ===\n");

        // --- 1. await catches normally ---
        Console.WriteLine("1) await — catches the ORIGINAL exception:");
        try
        {
            await FailingMethodAsync();
        }
        catch (InvalidOperationException ex)
        {
            Console.WriteLine($"   ✅ Caught: {ex.GetType().Name} — \"{ex.Message}\"\n");
        }

        // --- 2. Not awaiting — exception is silent ---
        Console.WriteLine("2) Not awaiting — exception is SILENT:");
        try
        {
            var task = FailingMethodAsync(); // no await!
            Console.WriteLine("   ⚠️ No exception thrown here. The Task contains it, but nobody observed it.");
            // Let's observe it manually:
            Console.WriteLine($"   Task status: {task.Status}");
            await Task.Delay(100); // give it time to complete
            Console.WriteLine($"   Task status after delay: {task.Status}");
            Console.WriteLine($"   Task.Exception: {task.Exception?.InnerException?.Message}\n");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"   This line should NOT execute: {ex.Message}\n");
        }

        // --- 3. .Result wraps in AggregateException ---
        Console.WriteLine("3) .Result — wraps in AggregateException:");
        try
        {
            var result = FailingMethodWithResultAsync().Result; // blocks + wraps
        }
        catch (AggregateException ex)
        {
            Console.WriteLine($"   ✅ Caught: {ex.GetType().Name}");
            Console.WriteLine($"   Inner: {ex.InnerException?.GetType().Name} — \"{ex.InnerException?.Message}\"\n");
        }

        // --- 4. GetAwaiter().GetResult() throws original ---
        Console.WriteLine("4) GetAwaiter().GetResult() — throws ORIGINAL exception (still blocks!):");
        try
        {
            FailingMethodWithResultAsync().GetAwaiter().GetResult(); // blocks but no wrapping
        }
        catch (InvalidOperationException ex)
        {
            Console.WriteLine($"   ✅ Caught: {ex.GetType().Name} — \"{ex.Message}\"");
            Console.WriteLine($"   (No AggregateException wrapper, but it still BLOCKS the thread!)\n");
        }

        // --- 5. Multiple task failures with WhenAll ---
        Console.WriteLine("5) Task.WhenAll — await throws only the FIRST exception:");
        var tasks = new[]
        {
            FailWithMessageAsync("Error from Task A"),
            FailWithMessageAsync("Error from Task B"),
            FailWithMessageAsync("Error from Task C"),
        };

        try
        {
            await Task.WhenAll(tasks);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"   await caught: \"{ex.Message}\" (only the first!)");
            Console.WriteLine("   Inspecting all tasks individually:");
            foreach (var t in tasks)
            {
                if (t.Exception != null)
                    foreach (var inner in t.Exception.InnerExceptions)
                        Console.WriteLine($"     - {inner.Message}");
            }
        }

        Console.WriteLine("\n--- Summary ---");
        Console.WriteLine("  await task           → original exception");
        Console.WriteLine("  task.Result          → AggregateException");
        Console.WriteLine("  GetAwaiter().GetResult() → original (still blocks!)");
        Console.WriteLine("  Not awaiting         → exception is silent");
        Console.WriteLine("  async void           → crashes the process");
    }

    private static async Task FailingMethodAsync()
    {
        await Task.Delay(50);
        throw new InvalidOperationException("Something went wrong in async code");
    }

    private static async Task<string> FailingMethodWithResultAsync()
    {
        await Task.Delay(50);
        throw new InvalidOperationException("Something went wrong in async code");
    }

    private static async Task FailWithMessageAsync(string message)
    {
        await Task.Delay(50);
        throw new Exception(message);
    }
}
