namespace Demos.Block4_Exceptions;

/// <summary>
/// Slide 42 — Exercise: Fix the Broken Code
/// This file contains BOTH the broken version and the fixed version.
/// During the presentation, show the broken version first and ask the audience to spot the bugs.
/// </summary>
public static class BrokenCode
{
    public static async Task RunAsync()
    {
        Console.WriteLine("=== Fix the Broken Code Exercise ===\n");

        // --- BROKEN VERSION ---
        Console.WriteLine("1) BROKEN version — async void + missing await:");
        Console.WriteLine("   Running ProcessOrderBroken...");
        try
        {
           await ProcessOrderBroken(new Order("ORD-001", false));
            Console.WriteLine("   ⚠️ No exception caught! The try/catch didn't work.");
            Console.WriteLine("   Bug 1: async void — exceptions can't be caught by the caller.");
            Console.WriteLine("   Bug 2: Missing await — caller doesn't wait for completion.\n");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"   Caught: {ex.Message} (this line should NOT execute)\n");
        }

        await Task.Delay(500); // let the async void crash happen (if it does)

        // --- FIXED VERSION ---
        Console.WriteLine("2) FIXED version — async Task + await:");
        Console.WriteLine("   Running ProcessOrderFixed...");
        try
        {
            await ProcessOrderFixed(new Order("ORD-002", false));
        }
        catch (Exception ex)
        {
            Console.WriteLine($"   ✅ Caught: \"{ex.Message}\"");
            Console.WriteLine("   The exception was properly caught because:");
            Console.WriteLine("   - Method returns Task (not void) → exception is captured in the Task");
            Console.WriteLine("   - Caller uses await → exception is unwrapped and thrown\n");
        }

        Console.WriteLine("--- Two bugs in the broken version ---");
        Console.WriteLine("  1. async void → change to async Task");
        Console.WriteLine("  2. Missing await → add await before the call");
    }

    // ---- BROKEN: async void + caller doesn't await ----
    private static async Task ProcessOrderBroken(Order order)
    {
        var result = await SubmitOrderAsync(order);
        if (!result.Success)
            throw new Exception($"Order {order.Id} failed");
    }

    // ---- FIXED: async Task + caller awaits ----
    private static async Task ProcessOrderFixed(Order order)
    {
        var result = await SubmitOrderAsync(order);
        if (!result.Success)
            throw new Exception($"Order {order.Id} failed");
    }

    private static async Task<OrderResult> SubmitOrderAsync(Order order)
    {
        await Task.Delay(100); // simulate service call
        return new OrderResult(order.ShouldSucceed);
    }

    private record Order(string Id, bool ShouldSucceed);
    private record OrderResult(bool Success);
}
