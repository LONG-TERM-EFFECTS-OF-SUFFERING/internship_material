namespace Demos.Block5_Deadlocks;

/// <summary>
/// Slide 44 — The Classic Deadlock Example
/// 
/// WARNING: In a console app (no SynchronizationContext), this won't actually deadlock.
/// The deadlock happens in WPF/WinForms/classic ASP.NET where a SynchronizationContext exists.
/// 
/// This demo EXPLAINS the deadlock step-by-step and shows why .Result is dangerous.
/// To show a real deadlock, you'd need a WPF or WinForms app.
/// </summary>
public static class DeadlockDemo
{
    public static void Run()
    {
        Console.WriteLine("=== Classic Deadlock Demonstration ===\n");

        Console.WriteLine("SCENARIO: What happens when you call .Result on an async method?\n");

        // --- In a console app, this works (no SynchronizationContext) ---
        Console.WriteLine("1) Console app — NO deadlock (no SynchronizationContext):");
        Console.WriteLine("   Calling GetDataAsync().Result...");
        var result = GetDataAsync().Result;
        Console.WriteLine($"   Result: {result}");
        Console.WriteLine("   ✅ This worked! But ONLY because console apps have no SynchronizationContext.\n");

        // --- Explain what would happen in WPF ---
        Console.WriteLine("2) In WPF / WinForms — DEADLOCK would occur:");
        Console.WriteLine("   Step 1: Button_Click runs on the UI thread");
        Console.WriteLine("   Step 2: GetDataAsync() hits 'await Task.Delay(1000)'");
        Console.WriteLine("           → Captures the DispatcherSynchronizationContext (UI thread)");
        Console.WriteLine("           → Pauses and returns to Button_Click");
        Console.WriteLine("   Step 3: .Result BLOCKS the UI thread");
        Console.WriteLine("   Step 4: Task.Delay completes → continuation wants the UI thread");
        Console.WriteLine("   Step 5: UI thread is BLOCKED by .Result → can't run the continuation");
        Console.WriteLine("   Step 6: 💀 DEADLOCK — both wait forever\n");

        Console.WriteLine("   The problematic WPF code would look like:");
        Console.WriteLine("   ┌─────────────────────────────────────────────┐");
        Console.WriteLine("   │ public void Button_Click(object s, EventArgs e) │");
        Console.WriteLine("   │ {                                           │");
        Console.WriteLine("   │     var text = LoadTextAsync().Result; // 💀│");
        Console.WriteLine("   │     label1.Text = text;                     │");
        Console.WriteLine("   │ }                                           │");
        Console.WriteLine("   └─────────────────────────────────────────────┘\n");

        // --- Show ConfigureAwait(false) workaround ---
        Console.WriteLine("3) ConfigureAwait(false) — avoids the deadlock:");
        Console.WriteLine("   Calling GetDataWithConfigureAwaitAsync().Result...");
        var result2 = GetDataWithConfigureAwaitAsync().Result;
        Console.WriteLine($"   Result: {result2}");
        Console.WriteLine("   ConfigureAwait(false) tells the continuation to run on the ThreadPool,");
        Console.WriteLine("   NOT the original context. So even if the UI thread is blocked, it works.\n");

        Console.WriteLine("--- Mitigation Rules ---");
        Console.WriteLine("  1. Async all the way — never mix sync and async");
        Console.WriteLine("  2. Avoid .Result and .Wait() — always prefer await");
        Console.WriteLine("  3. Use ConfigureAwait(false) in library code");
        Console.WriteLine("  4. Use SemaphoreSlim.WaitAsync() instead of lock");
    }

    private static async Task<string> GetDataAsync()
    {
        await Task.Delay(500);
        return "Data from async method";
    }

    private static async Task<string> GetDataWithConfigureAwaitAsync()
    {
        await Task.Delay(500).ConfigureAwait(false);
        return "Data with ConfigureAwait(false)";
    }
}
