using System.Diagnostics;

namespace Demos.Block5_Deadlocks;

/// <summary>
/// Slides 47–48 — I/O-Bound vs CPU-Bound
/// Shows the difference between I/O-bound and CPU-bound work,
/// and the correct async pattern for each.
/// </summary>
public static class IoBoundVsCpuBound
{
    public static async Task RunAsync()
    {
        Console.WriteLine("=== I/O-Bound vs CPU-Bound ===\n");

        // --- I/O-BOUND ---
        Console.WriteLine("1) I/O-BOUND — Simulated HTTP call (async/await):");
        Console.WriteLine("   The thread is RELEASED while waiting for the response.\n");

        var sw = Stopwatch.StartNew();
        var threadBefore = Thread.CurrentThread.ManagedThreadId;
        Console.WriteLine($"   Thread before await: {threadBefore}");

        var ioResult = await SimulateHttpCallAsync();

        var threadAfter = Thread.CurrentThread.ManagedThreadId;
        sw.Stop();
        Console.WriteLine($"   Thread after  await: {threadAfter}");
        Console.WriteLine($"   Result: {ioResult}");
        Console.WriteLine($"   Elapsed: {sw.ElapsedMilliseconds} ms");
        Console.WriteLine($"   → Thread was FREE during the {sw.ElapsedMilliseconds} ms wait.\n");

        // --- CPU-BOUND ---
        Console.WriteLine("2) CPU-BOUND — Heavy calculation (Task.Run):");
        Console.WriteLine("   The work is offloaded to a ThreadPool thread.\n");

        sw.Restart();
        threadBefore = Thread.CurrentThread.ManagedThreadId;
        Console.WriteLine($"   Thread before Task.Run: {threadBefore}");

        var cpuResult = await Task.Run(() =>
        {
            Console.WriteLine($"   [Inside Task.Run] Thread: {Thread.CurrentThread.ManagedThreadId}");
            return HeavyCalculation();
        });

        threadAfter = Thread.CurrentThread.ManagedThreadId;
        sw.Stop();
        Console.WriteLine($"   Thread after  Task.Run: {threadAfter}");
        Console.WriteLine($"   Result: {cpuResult:N0} (sum of square roots)");
        Console.WriteLine($"   Elapsed: {sw.ElapsedMilliseconds} ms");
        Console.WriteLine($"   → A ThreadPool thread did the heavy lifting.\n");

        // --- WRONG: Task.Run for I/O ---
        Console.WriteLine("3) WRONG — Using Task.Run for I/O (wastes a thread):");
        sw.Restart();

        var wrongResult = await Task.Run(async () =>
        {
            Console.WriteLine($"   [Inside Task.Run] Thread: {Thread.CurrentThread.ManagedThreadId} (wasted!)");
            return await SimulateHttpCallAsync();
        });

        sw.Stop();
        Console.WriteLine($"   Result: {wrongResult}");
        Console.WriteLine($"   Elapsed: {sw.ElapsedMilliseconds} ms");
        Console.WriteLine("   ⚠️ Same result, but we wasted a ThreadPool thread for no reason.");
        Console.WriteLine("   On a server under load, this causes thread pool starvation!\n");

        Console.WriteLine("--- Summary ---");
        Console.WriteLine("  I/O-bound (network, DB, disk) → async/await (no thread needed)");
        Console.WriteLine("  CPU-bound (calculations)       → Task.Run (offload to ThreadPool)");
        Console.WriteLine("  Don't wrap I/O in Task.Run on servers — it wastes threads.");
    }

    private static async Task<string> SimulateHttpCallAsync()
    {
        await Task.Delay(1000); // simulate network I/O
        return "HTTP 200 OK — response data";
    }

    private static double HeavyCalculation()
    {
        double sum = 0;
        for (int i = 0; i < 10_000_000; i++)
            sum += Math.Sqrt(i);
        return sum;
    }
}
