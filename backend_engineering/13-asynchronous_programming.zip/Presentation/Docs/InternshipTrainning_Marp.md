---
marp: true
theme: default
paginate: true
size: 16:9
style: |
  section {
    font-size: 28px;
  }
  section.title {
    text-align: center;
    font-size: 36px;
  }
  section.exercise {
    background-color: #f0f7ff;
    border-left: 8px solid #2196F3;
  }
  section.demo {
    background-color: #fff8e1;
    border-left: 8px solid #FF9800;
  }
  section.break {
    text-align: center;
    font-size: 40px;
    background-color: #e8f5e9;
  }
  table { font-size: 24px; }
  code { font-size: 22px; }
  blockquote { font-size: 24px; border-left: 4px solid #2196F3; }
---

<!-- _class: title -->

# Asynchronous Programming in C#

**Internship Training Session**

*Duration: 2 hours*

<!-- Speaker notes:
Welcome everyone. Today we'll build a solid mental model of async programming in C#.
No prior async experience needed — we'll start from scratch.
-->

---

# Agenda

| Block | Topic | Time |
|-------|-------|------|
| **1** | Foundations: async/await & Thread vs Task | 0:00 – 0:30 |
| **2** | Under the Hood: State Machine, Continuation, Context | 0:30 – 1:00 |
| ☕ | **Break** | 1:00 – 1:10 |
| **3** | TAP & Practical Patterns | 1:10 – 1:30 |
| **4** | Exception Handling in Async Code | 1:30 – 1:45 |
| **5** | Deadlocks, I/O vs CPU Bound, Wrap-Up | 1:45 – 2:00 |

*Exercises included at the end of each block (~3–5 min each)*

---

<!-- _class: title -->

# BLOCK 1
## Foundations: async/await & Thread vs Task
*30 minutes*

---

# What Are `async` and `await`?

- **`async`** — Marks a method as "I might need to pause and wait for something"
- **`await`** — The actual pause point: "Start this work, and when it finishes, come back here"

```csharp
var data = await client.GetStringAsync(url);
```

> Under the hood, the compiler rewrites your `async` method into a **state machine** so it can pause and resume later.

---

# What Does `await` Actually Do?

### Three Steps

1. Call the method → it returns a `Task<T>` immediately (a "promise")
2. If the task is **not finished yet** → return to the caller, register a continuation
3. When it **completes** → unwrap the result, rethrow exceptions, or throw if canceled

> **One sentence:** "If this operation hasn't finished yet, pause this method, return control to the caller, and resume here later when the result is available."

---

# What Is "The Caller"?

```csharp
public async Task HandleRequestAsync()       // ← CALLER of GetDataFromDbAsync
{
    var data = await GetDataFromDbAsync();    // ← method being called
    Process(data);
}
```

When `GetDataFromDbAsync` awaits, it **pauses** and returns to `HandleRequestAsync`.
But `HandleRequestAsync` is **also** awaiting — so it **also pauses** and returns to *its* caller.

> **"Returns to the caller" does NOT mean the caller keeps running its next lines.**
> It means the **thread is freed**. All methods in the chain pause.

---

# The Caller — Full Call Chain

```
Controller → HandleRequestAsync → GetDataFromDbAsync
```

| Step | What happens |
|------|-------------|
| 1–2 | Each method calls the next with `await` |
| 3 | `GetDataFromDbAsync` awaits (DB not done) → **pauses**, returns up |
| 4–5 | Each caller is also awaiting → **also pauses**, returns up |
| 6 | **Framework gets the thread back** → serves other requests |

**WHO keeps working?** Not your methods — they all pause.
The **runtime / thread pool** reuses the freed thread.

---

# Three Consequences of `await`

### 1. It does NOT block the current thread
```csharp
var result = GetDataAsync().Result;    // BAD — blocks
var result = await GetDataAsync();     // GOOD — releases thread
```

### 2. It splits your method in two
- Method **returns before it finishes**, local variables are **preserved**
- Execution resumes **exactly after the await**

### 3. It propagates results, exceptions, and cancellation automatically
```csharp
try { await FailingAsync(); }
catch (Exception ex) { /* caught HERE */ }
```

---

# Common Myths

| Myth | Reality |
|------|---------|
| "async runs on another thread" | No. Most async I/O runs on **no thread at all** while waiting |
| "async makes code faster" | No. It makes code more **scalable** and **responsive** |
| "async means parallel" | No. Parallelism only happens if you start multiple tasks at once |

> **Better definition:** Async is about **suspending and resuming execution**, not threads.

---

# Thread vs Task vs Async: Thread

### Thread = An OS-Level Worker

A **person** who can do one thing at a time. Expensive (~1 MB stack each).

```csharp
var thread = new Thread(() => Console.WriteLine("I'm on a new thread"));
thread.Start();
```

**When to use:** Almost never directly. Use `Task.Run` instead.

---

# Thread vs Task vs Async: Task

### Task = A Promise of Future Work

A `Task` is **NOT** a thread. It may or may not involve a thread.

```csharp
Task<string> t1 = httpClient.GetStringAsync(url);  // NO thread — I/O wait
Task t2 = Task.Run(() => HeavyCalculation());       // YES thread — CPU work
Task t3 = Task.Delay(2000);                         // NO thread — timer
```

**Analogy:** A `Task` is like a **receipt** from a repair shop. The receipt isn't the mechanic — it just tracks whether the work is done.

---

# Thread vs Task vs Async: Async/Await

### Async/Await = Language Syntax

A **language feature** that lets you write code that pauses and resumes. Works **on top of** Tasks.

```csharp
var data = await httpClient.GetStringAsync(url);
Process(data);
```

Without `async`/`await` you'd manually chain callbacks. The keywords make it look like normal sequential code.

---

# Thread vs Task vs Async: Comparison

| | **Thread** | **Task** | **Async/Await** |
|---|---|---|---|
| **What is it?** | An OS worker | A promise of future work | Language syntax |
| **Level** | Low-level (OS) | Mid-level (runtime) | High-level (compiler) |
| **Creates a thread?** | Always | Only if CPU-bound | Never by itself |
| **Cost** | ~1 MB stack | Lightweight object | Zero cost (compiler rewrite) |

```
async/await (syntax)     ← you write this
      |
    Task (abstraction)   ← compiler works with this
      |
  Thread (maybe)         ← OS may or may not be involved
```

> A Thread is a worker. A Task is a job ticket. Async/await lets you hand in the ticket and walk away.

---

<!-- _class: demo -->

# 🖥️ Demo: Why Async Matters on Servers

**→ Switch to Visual Studio — open `Demos/Block1_Foundations/ServerComparison.cs`**

We'll compare:
- **Blocking** — `GetDataAsync().Result` (thread stuck)
- **Async** — `await GetDataAsync()` (thread freed)

> **The Bookmark Analogy:** `await` is like putting a bookmark in your book — pause here, go do other things, come back later.

---

<!-- _class: exercise -->

# Exercise: Foundations Quiz (Audience)

### Quick-Fire Questions — Raise Your Hand!

**Q1: Does `await httpClient.GetStringAsync(url)` create a thread?**

**Q2: Does `await Task.Run(() => ComputeHash(data))` create a thread?**

**Q3: Does `await Task.Delay(3000)` create a thread?**

**Q4: Who is the "caller" in an ASP.NET Core controller action?**

**Q5: What's wrong with `var result = GetDataAsync().Result;`?**

<!-- Speaker notes:
Q1: No — I/O-bound, OS handles it
Q2: Yes — Task.Run queues onto ThreadPool
Q3: No — system timer, no thread
Q4: The ASP.NET Core framework pipeline
Q5: Blocks synchronously, can deadlock, kills scalability. Use await.
-->

---

<!-- _class: title -->

# BLOCK 2
## Under the Hood: State Machine, Continuation, Context
*30 minutes*

---

# Who Runs the Async Operation?

| Scenario | What happens | Thread used while waiting? |
|---|---|---|
| **I/O-bound** (`HttpClient.GetAsync`) | OS kernel handles I/O | No thread at all |
| **CPU-bound** (`Task.Run(() => Work())`) | ThreadPool thread runs it | Yes (ThreadPool) |
| **Timer-based** (`Task.Delay(1000)`) | System timer fires later | No thread at all |

> **Mental model:** Async is event-driven, not thread-driven.

---

# How Does `await` Know the Task Completed?

### Callback Registration

```csharp
if (!someTask.IsCompleted)
{
    someTask.GetAwaiter().OnCompleted(ResumeMethod);
    return; // give up the thread
}
ResumeMethod();
```

The task signals completion → `await` just registers a callback.
No polling, no thread sitting there.

---

<!-- _class: demo -->

# 🖥️ Demo: Thread IDs Before & After Await

**→ Switch to Visual Studio — open `Demos/Block2_UnderTheHood/ThreadIdDemo.cs`**

```csharp
Console.WriteLine($"Before: {Thread.CurrentThread.ManagedThreadId}");
await Task.Delay(1000);
Console.WriteLine($"After: {Thread.CurrentThread.ManagedThreadId}");
```

Watch the thread ID change — proof that execution resumes on a **different thread**.

| Environment | Resume location |
|---|---|
| ASP.NET Core / Console | ThreadPool |
| WPF / WinForms | UI thread |
| With `ConfigureAwait(false)` | ThreadPool |

---

# State Machine: WHAT Code Runs Next

The compiler transforms your `async` method into a **state machine** — a checklist with numbered steps.

```csharp
// Your code:
async Task Foo() { A(); await B(); C(); }

// Compiler creates (simplified):
int state = 0;
void MoveNext()
{
    if (state == 0) { A(); var task = B();
        if (!task.IsCompleted) { state = 1; task.GetAwaiter().OnCompleted(MoveNext); return; }
    }
    if (state == 1) { task.GetAwaiter().GetResult(); C(); }
}
```

> The state machine remembers **which step you're on** and **all your local variables**.

---

# Continuation: WHEN to Resume

A continuation is a **callback** scheduled to run when an async operation completes.

In the previous example, `MoveNext` is the continuation registered with the task.

**Doorbell analogy:** It doesn't contain the house (logic), it just **triggers** someone to come to the door (resume the state machine).

> A continuation is the trigger; the state machine is the map.

---

# Context: WHERE to Resume

Context is the **scheduler/dispatcher** that decides which thread runs your continuation.

| App type | Context | Continuations run on |
|---|---|---|
| WPF / WinForms | `DispatcherSynchronizationContext` | UI thread (only one!) |
| ASP.NET (classic) | `AspNetSynchronizationContext` | Request thread |
| ASP.NET Core | None | ThreadPool (any thread) |
| Console app | None | ThreadPool (any thread) |

> Context is NOT a thread. It's a **rule**: "Where should the rest of my method run?"

---

# How They Work Together

```
await registers continuation + captured context
            |
Task completes (signals "I'm done")
            |
Awaiter uses context to schedule the continuation
            |
A thread (chosen by context) executes MoveNext()
            |
State machine resumes at the correct step
```

| Responsibility | Who does it |
|---|---|
| Knows **what** code runs next | State machine |
| Knows **when** to resume | Task completion |
| Knows **where** to run it | Context / TaskScheduler |
| Actually **runs** the code | A thread |

---

# ConfigureAwait(false)

### Controlling Where You Resume

```csharp
await task.ConfigureAwait(true);   // default: resume on original context
await task.ConfigureAwait(false);  // resume on ANY thread (usually ThreadPool)
```

- **Library code**: Use `ConfigureAwait(false)` — libraries shouldn't assume a context
- **UI code**: Do **not** use it — you need the UI thread
- **ASP.NET Core**: Usually unnecessary, but harmless in libraries

> **Why it exists:** avoids deadlocks, improves performance, keeps libraries context-agnostic.

---

# Control Flow Branches With `await`

1. **Task already completed (fast path)** — Runs synchronously, no pause
2. **Task incomplete (true async path)** — Method returns to caller, resumes later
3. **Task faults** — Exception rethrown at the `await` site
4. **Task canceled** — `OperationCanceledException` thrown

<!-- Speaker notes:
Show examples in VS for each branch if time permits:
- Task.FromResult (fast path)
- Real HTTP call (async path)
- Task.Run(() => throw ...) (faulted)
- Task.Delay with cancellation token (canceled)
-->

---

<!-- _class: exercise -->

# Exercise: Trace the Async Flow (Presenter Walkthrough)

**→ Switch to Visual Studio — open `Demos/Block2_UnderTheHood/TraceAsyncFlow.cs`**

```csharp
public async Task LoadAndDisplayAsync()
{
    Console.WriteLine("Step 1");                    // line A
    var data = await GetFromApiAsync();              // line B
    Console.WriteLine($"Step 2: {data}");           // line C
    await Task.Delay(500);                          // line D
    Console.WriteLine("Step 3");                    // line E
}
```

**Q1:** At line B, the task is NOT complete. What happens?
**Q2:** Which "state" is the state machine in after line B pauses?
**Q3:** In WPF, which thread runs line C?
**Q4:** With `.ConfigureAwait(false)` on line B, which thread runs line C?
**Q5:** What is the continuation at line D?

<!-- Speaker notes:
Q1: State machine saves state=0, registers MoveNext, returns to caller. Thread released.
Q2: State 1. When complete, MoveNext runs and jumps to line C.
Q3: UI thread (DispatcherSynchronizationContext captured).
Q4: Any ThreadPool thread. If line C touches UI → crash!
Q5: MoveNext itself. State machine advances to state 2, then executes line E.
-->

---

<!-- _class: break -->

# ☕ BREAK
## 10 minutes
*1:00 – 1:10*

---

<!-- _class: title -->

# BLOCK 3
## TAP & Practical Patterns
*20 minutes*

---

# What Is TAP?

### Task-based Asynchronous Pattern

TAP is the standard .NET pattern for representing async operations using `Task` and `Task<T>`.

> "An async operation returns a `Task` that represents work that will finish in the future."

Everything else (`await`, continuations, context, state machines) is built on top of this one idea.

**Before TAP:** .NET had APM (`BeginXxx`/`EndXxx`) and EAP (`XxxAsync` + events) — both hard to compose and error-prone.

---

# The TAP Contract (The Rules)

1. **Return `Task` or `Task<T>`**
2. **Start work immediately** — calling begins the operation right away
3. **The returned Task represents the entire operation** — Completed, Faulted, or Canceled
4. **Errors are reported via the Task** — rethrown when you `await`
5. **Cancellation uses `CancellationToken`**
6. **Naming convention: `Async` suffix** — `GetAsync`, `SaveAsync`, `LoadAsync`

```csharp
Task SaveAsync();
Task<User> GetUserAsync();
Task DownloadAsync(CancellationToken token);
```

> TAP is the contract. async/await is the syntax. They were designed together.

---

<!-- _class: demo -->

# 🖥️ Demo: Sequential vs Concurrent Awaits

**→ Switch to Visual Studio — open `Demos/Block3_TAP/SequentialVsConcurrent.cs`**

We'll run both and compare the elapsed time:

```
Sequential:   A ────────────────✔
                                B ───────────────✔   (total: A + B)

Concurrent:   A ────────────────✔
              B ────────────────✔                    (total: max(A, B))
```

> **Golden rule:** Concurrency happens at **task creation**, not at `await`.

---

# Task.WhenAll and Task.WhenAny

**`Task.WhenAll`** — completes when **all** tasks complete:
```csharp
string[] results = await Task.WhenAll(GetAAsync(), GetBAsync());
```

**`Task.WhenAny`** — completes when the **first** task completes (useful for timeouts):
```csharp
var work = DoWorkAsync();
var timeout = Task.Delay(2000);
var completed = await Task.WhenAny(work, timeout);
if (completed == timeout) throw new TimeoutException();
await work; // observe exceptions
```

---

# Task.Run, GetAwaiter, and Task.Result

**`Task.Run`** — queues work on the ThreadPool. Use for **CPU-bound** work only:
```csharp
await Task.Run(() => DoCpuWork());
```

**Blocking alternatives** (avoid when possible):
```csharp
task.Wait();                        // throws AggregateException
task.Result;                        // throws AggregateException
task.GetAwaiter().GetResult();      // throws original exception
```

> All three **block** and can **deadlock** — prefer `await`.

---

# async Task vs async void vs ValueTask

| Return type | Use case | Can be awaited? | Exception behavior |
|---|---|---|---|
| **`async Task`** | Standard async methods | ✅ Yes | Captured in Task |
| **`async Task<T>`** | Returns a value | ✅ Yes | Captured in Task |
| **`async void`** | Event handlers ONLY | ❌ No | Crashes the process! |
| **`ValueTask`** | Performance optimization | ✅ Yes | Advanced — avoid for now |

> **Rule:** Never use `async void` except for event handlers.

---

<!-- _class: demo -->

# 🖥️ Demo: Fan-Out, Throttling & Retry

**→ Switch to Visual Studio — open `Demos/Block3_TAP/PatternsDemo.cs`**

We'll see three patterns live:

- **Fan-out:** Fire multiple tasks with `Task.WhenAll`
- **Throttling:** Limit concurrency with `SemaphoreSlim`
- **Retry:** Retry with exponential delay

> **TAP reminder:** TAP does NOT mean "run on another thread." It means: represent async work as a `Task`.

---

<!-- _class: exercise -->

# Exercise: Refactor & Fix — Part 1 (Audience)

**Exercise 1:** Refactor sequential → concurrent:
```csharp
var users = await GetUsersAsync();
var orders = await GetOrdersAsync();
```

**Exercise 2:** Is this TAP-compliant? What's wrong?
```csharp
public async void SaveUserAsync(User user)
{
    await _db.SaveAsync(user);
}
```

<!-- Speaker notes:
Ex1: Start both tasks first, then await both. Or use Task.WhenAll.
Ex2: Returns void, should return Task. async void crashes on exceptions.
-->

---

<!-- _class: exercise -->

# Exercise: Refactor & Fix — Part 2 (Audience)

**Exercise 3:** Add cancellation support to:
```csharp
public async Task<string> FetchDataAsync(string url)
{
    using var client = new HttpClient();
    return await client.GetStringAsync(url);
}
```

<!-- Speaker notes:
Ex3: Add CancellationToken parameter, pass to GetStringAsync.
-->

---

<!-- _class: exercise -->

# Exercise: Sequential or Concurrent? (Audience)

**Snippet A:**
```csharp
var a = await DoAAsync();
var b = await DoBAsync();
```

**Snippet B:**
```csharp
var tA = DoAAsync();
var tB = DoBAsync();
await Task.WhenAll(tA, tB);
```

**Snippet C:**
```csharp
var tA = DoAAsync();
var a = await tA;
var tB = DoBAsync();
var b = await tB;
```

<!-- Speaker notes:
A: Sequential — B doesn't start until A finishes.
B: Concurrent — both start immediately, then we wait for both.
C: Sequential — we immediately await tA before starting tB.
-->

---

<!-- _class: title -->

# BLOCK 4
## Exception Handling in Async Code
*15 minutes*

---

# The Core Idea

In async code, exceptions work differently:
- Exceptions are **captured inside the Task**
- They are **thrown when you `await`**, not when the task starts

**Letter analogy:** The bad news is sealed inside the envelope (`Task`). You only read it when you open the envelope (`await`).

```csharp
// Exception is thrown HERE at the await, not when DoWorkAsync() is called
try { await DoWorkAsync(); }
catch (Exception ex) { Console.WriteLine(ex.Message); }
```

---

# What If You Don't `await`?

```csharp
try
{
    var task = DoWorkAsync(); // no await!
}
catch (Exception ex)
{
    // This will NOT catch the exception!
}
```

The exception is stored inside the `Task` but **never observed**.
Like receiving the letter but never opening it.

---

# AggregateException & Multiple Failures

`.Wait()` and `.Result` **wrap** exceptions in `AggregateException`:
```csharp
try { task.Wait(); }
catch (AggregateException ex) { Console.WriteLine(ex.InnerException.Message); }
```

When multiple tasks fail with `Task.WhenAll`, `await` throws only the **first** exception. To see **all**:
```csharp
try { await Task.WhenAll(tasks); }
catch
{
    foreach (var task in tasks)
        if (task.Exception != null)
            foreach (var inner in task.Exception.InnerExceptions)
                Console.WriteLine(inner.Message);
}
```

---

# async void: The Danger Zone

```csharp
public async void DoSomething()
{
    throw new Exception("Boom"); // crashes the process!
}
```

- **Cannot be awaited**
- Exceptions **crash the process** or go unobserved
- **Cannot be caught** with try/catch

> Only use `async void` for **event handlers** (e.g., button clicks).

---

# Exception Flow & Best Practices

Exceptions propagate naturally through async chains:
```csharp
public async Task A() { await B(); }
public async Task B() { throw new Exception("Failure in B"); }

try { await A(); }
catch (Exception ex) { Console.WriteLine(ex.Message); } // "Failure in B"
```

**Best Practices:**
- **Always `await` tasks** — so exceptions are observed
- **Use try/catch around `await`** — just like synchronous code
- **Avoid `.Result` / `.Wait()`** — they cause deadlocks and wrap exceptions
- **Use `async Task`, NOT `async void`** — so exceptions can be caught

---

# Exception Handling Summary

| Approach | Exception behavior |
|---|---|
| `await task` | Throws **original** exception |
| `task.Result` / `task.Wait()` | Wraps in **AggregateException** |
| `task.GetAwaiter().GetResult()` | Throws **original** exception (still blocks!) |
| `async void` | **Crashes** the process |
| Not awaiting at all | Exception is **silent** / unobserved |

---

<!-- _class: exercise -->

# Exercise: Will It Catch? (Audience Quiz)

**Snippet 1:** `try { await DoWorkAsync(); } catch { ... }`

**Snippet 2:** `try { var t = DoWorkAsync(); } catch { ... }`

**Snippet 3:** `try { DoWorkAsync().Wait(); } catch { ... }`

**Snippet 4:** `async void` method + `try { FireAndForget(); } catch { ... }`

<!-- Speaker notes:
1: YES — await unwraps the exception.
2: NO — task never awaited, exception sealed inside.
3: PARTIALLY — catches AggregateException, not original. Also blocks & can deadlock.
4: NO — async void exceptions can't be caught. Crashes the process.
-->

---

<!-- _class: exercise -->

# Exercise: Fix the Broken Code (Audience)

**→ Switch to Visual Studio — open `Demos/Block4_Exceptions/BrokenCode.cs`**

```csharp
public async void ProcessOrderAsync(Order order)
{
    var result = await _service.SubmitAsync(order);
    if (!result.Success) throw new Exception("Order failed");
}

// Caller:
try { ProcessOrderAsync(myOrder); }
catch (Exception ex) { _logger.LogError(ex, "Order processing failed"); }
```

**Find the two bugs and fix them.**

<!-- Speaker notes:
Bug 1: async void — change to async Task
Bug 2: Missing await in the caller — add await
-->

---

<!-- _class: title -->

# BLOCK 5
## Deadlocks, I/O vs CPU Bound, Wrap-Up
*15 minutes*

---

# What Is a Deadlock?

**Hallway analogy:** Two people in a narrow hallway, each waiting for the other to move first. Neither can move — stuck forever.

In C# async code, a deadlock usually happens when:
1. Code starts an async operation
2. **Blocks synchronously** waiting for it (`.Result`, `.Wait()`)
3. The continuation tries to **resume on the same blocked thread**

---

<!-- _class: demo -->

# 🖥️ Demo: The Classic Deadlock

**→ Switch to Visual Studio — open `Demos/Block5_Deadlocks/DeadlockDemo.cs`**

```csharp
public string GetData()
{
    return GetDataAsync().Result; // BLOCKS the thread
}
```

**Step by step:**
1. `GetData()` runs on the calling thread
2. `GetDataAsync()` hits `await` → captures context → pauses
3. `.Result` **blocks** the thread
4. Continuation wants that same thread → **it's blocked**
5. **Both wait forever** — deadlock!

---

# Deadlock Mitigation Rules

1. **Async all the way** — If a method calls async code, make it async too
2. **Avoid `.Result` and `.Wait()`** — Always prefer `await`
3. **Use `ConfigureAwait(false)` in library code** — Don't capture the context
4. **Separate CPU-bound and I/O-bound** properly
5. **Use async-friendly synchronization** — `SemaphoreSlim.WaitAsync()`, not `lock`

> **Interview one-liner:** `.Result` sometimes deadlocks because the calling thread blocks waiting for the async method, while the continuation is waiting to resume on that same blocked thread.

---

# Deadlock vs Thread Pool Starvation

| | Deadlock | Thread Pool Starvation |
|---|---|---|
| **What happens** | Circular wait — nothing moves | Too many threads blocked, none free |
| **Cause** | Blocking on async + context capture | Many `.Result`/`.Wait()` calls under load |
| **Looks like** | App hangs forever | App becomes very slow |

---

# I/O-Bound vs CPU-Bound

Every program spends its time: **waiting** or **thinking**.

- **I/O-bound** = mostly **waiting** (network, disk, database) → use `async`/`await`
- **CPU-bound** = mostly **thinking** (heavy calculations) → use `Task.Run`

| Feature | I/O-Bound | CPU-Bound |
|---|---|---|
| **Bottleneck** | Disk, Network, Database | Processor (CPU) speed |
| **C# Pattern** | `async` / `await` | `Task.Run` / `Parallel.ForEach` |
| **Effect of async** | Frees up threads for more work | No speed gain; just moves the work |

---

<!-- _class: demo -->

# 🖥️ Demo: I/O-Bound vs CPU-Bound Code

**→ Switch to Visual Studio — open `Demos/Block5_Deadlocks/IoBoundVsCpuBound.cs`**

**I/O-Bound:** thread released while waiting
```csharp
return await client.GetStringAsync(url);
```

**CPU-Bound:** offload to ThreadPool
```csharp
await Task.Run(() => { /* heavy computation */ });
```

> **Warning:** Don't spam `Task.Run` on servers — it just moves the bottleneck to the thread pool.

---

<!-- _class: exercise -->

# Exercise: Deadlock Detective (Presenter Demo + Audience)

**Scenario 1 — WPF button click:** `LoadTextAsync().Result` on UI thread?
**Scenario 2 — ASP.NET Core controller:** `GetDataAsync().Result`?
**Scenario 3 — Library with `ConfigureAwait(false)`:** `.Result` from UI?

<!-- Speaker notes:
1: YES deadlock — .Result blocks UI thread, continuation needs UI thread
2: No deadlock (no SyncContext in ASP.NET Core), BUT thread pool starvation. Still bad.
3: No deadlock — ConfigureAwait(false) resumes on ThreadPool. But .Result still bad practice.
-->

---

<!-- _class: exercise -->

# Exercise: I/O or CPU? (Audience)

| Task | I/O or CPU? |
|------|-------------|
| Calling a REST API to get user data | ? |
| Compressing a 2GB video file | ? |
| Reading a 500MB CSV from disk | ? |
| Training a machine learning model | ? |
| Querying a SQL database for orders | ? |
| Calculating the first 10 million prime numbers | ? |

<!-- Speaker notes:
REST API → I/O (async/await)
Compressing video → CPU (Task.Run)
Reading CSV → I/O (async/await)
Training ML → CPU (Task.Run/Parallel)
SQL query → I/O (async/await)
Calculating primes → CPU (Task.Run/Parallel)
-->

---

# Key Takeaways

| # | Rule |
|---|------|
| 1 | **`await` does not create threads** — it avoids blocking them |
| 2 | **Thread ≠ Task ≠ Async** — worker vs promise vs syntax |
| 3 | **State machine = WHAT, Continuation = WHEN, Context = WHERE** |
| 4 | **TAP is the contract** — async work = a `Task` |
| 5 | **Always `await` your tasks** — so exceptions are observed |
| 6 | **Async all the way** — never block with `.Result` / `.Wait()` |
| 7 | **`ConfigureAwait(false)`** in library code |
| 8 | **I/O → async/await, CPU → Task.Run** |

---

<!-- _class: title -->

# Questions?

🎉 **Thank you!**
